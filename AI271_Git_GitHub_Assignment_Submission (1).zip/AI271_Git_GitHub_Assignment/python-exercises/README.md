# python-exercises

This repository contains Python exercise solutions for AI 271 – Programming for AI.

## Main notebook
- `exercise1.ipynb` – Solutions to all seven assignment questions:
  1. Reverse a string and select every second character.
  2. Square even numbers using list comprehension.
  3. Count character frequency with a dictionary.
  4. Build a dictionary using `zip()`.
  5. Iterate manually with `iter()` and `next()`, handling `StopIteration`.
  6. Check a palindrome using slicing.
  7. Find the second-largest distinct number without sorting.

## Run
Open `exercise1.ipynb` in Jupyter Notebook, VS Code, or Google Colab and run all cells from top to bottom.
